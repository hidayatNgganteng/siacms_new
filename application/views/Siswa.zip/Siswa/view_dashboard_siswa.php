<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <!-- Main content -->
  <section class="content">
    <!-- Small boxes (Stat box) -->

    <!-- /.row -->
    <!-- Main row -->
    <div class="row">
      <div class="col-md-12 ">

        <!-- Profile Image -->
        <div class="box box-primary box-dashboard">
          <div class="box-body box-profile">
          <br><br> <br><br> <br><br> <br><br> 
            <h2 align="center">Selamat Datang!</h2>
 <br>
            <div class="col-md-12">
              <h4 align="center"><?php echo $row_siswa->nama; ?></h4>
              <h4 align="center">NISN : <?php echo $row_siswa->nisn; ?></h4>
               <br><br>
            </div>
            <br><br>
            
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>

    </div>
    <!-- /.row (main row) -->

  </section>
  <!-- /.content -->
</div>